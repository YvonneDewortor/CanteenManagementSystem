<?php
session_start();
$servername = "localhost";
$server_user = "emeka_okechukwu";
$server_pass = "emeka_okechukwu";
$dbname = "webtech_fall2019_emeka_okechukwu";
$name = $_SESSION['name'];
$role = $_SESSION['role'];
$con = new mysqli($servername, $server_user, $server_pass, $dbname);
?>